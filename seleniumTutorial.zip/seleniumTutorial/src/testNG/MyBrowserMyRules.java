package testNG;

import java.sql.Driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;


public class MyBrowserMyRules {
	
	
	
	WebDriver driver;
	@BeforeSuite
	@Parameters("Browser")
	public void launchBrowser(String ChoosenBrowser ) {
		if(ChoosenBrowser.equalsIgnoreCase("Chrome")) 
		{
		System.out.println("Choosen Browser is" + ChoosenBrowser);
		System.setProperty("webdriver.chrome.driver","C:\\Users\\dselva001c\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
			
	}
	else if(ChoosenBrowser.equalsIgnoreCase("Firefox")) 
	{
		System.out.println("Choosen Browser is" + ChoosenBrowser);
		System.setProperty("webdriver.chrome.driver","C:\\Users\\dselva001c\\chromedriver_win32\\chromedriver.exe");
		driver = new FirefoxDriver();
		
	}
	else if (ChoosenBrowser.equalsIgnoreCase("IE")) 
	{
		System.out.println("Choosen Browser is" + ChoosenBrowser);
		System.setProperty("webdriver.chrome.driver","C:\\Users\\dselva001c\\chromedriver_win32\\chromedriver.exe");
		driver = new InternetExplorerDriver();	
	}
		
		
	}
		
	
	@Test
	
		
	public void OpenChrome() {
		
		driver.get("https://www.google.com");
		
		
	}
	
}
	

