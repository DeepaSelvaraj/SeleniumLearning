package testNG;

import org.testng.annotations.Test;

public class PrioritiesExample {
	
	@Test(priority=0)
	public void startEngine()
	{
		System.out.println("Engine started");
	}
	
	@Test(priority=2)
	public void firstGear() {
		System.out.println("In first Gear");
	}
	
	@Test(priority=1)
	public void secondGear() {
		System.out.println("In second Gear");
	}
	
	@Test(priority=3)
	public void thirdGear() {
		System.out.println("In Third Gear");
	}
	
	@Test(priority=4, enabled=false)
	public void turnOnMusic() {
		System.out.println("Music turned on");
		
	}
}
