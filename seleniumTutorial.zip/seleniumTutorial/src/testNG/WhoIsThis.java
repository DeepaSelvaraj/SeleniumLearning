package testNG;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;



public class WhoIsThis {
	
	@Test
	@Parameters("name")
	public void whoIsThis(String nameFromXml) {
		System.out.println("The Name is "+ nameFromXml);
		
	}
}
