package testNG;

import org.testng.annotations.Test;

public class HandlingDependents {

	@Test(dependsOnMethods = {"findGirlFallLove"})
	public void getMarried() {
		System.out.println("Get Married");
	}
	
	@Test(enabled=false)
	public void findGirlFallLove() {
		System.out.println("Find a girl and fall in love");
	}
	
	@Test
	public void haveKids() {
		System.out.println("Having Kids");
	}
}
