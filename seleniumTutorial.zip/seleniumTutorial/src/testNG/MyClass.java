package testNG;

import org.testng.annotations.Test;

public class MyClass extends SeleniumAbstractTest {
	@Test
	  public void myTestMethod1() {
	    System.out.println("myTestMethod1");
	  }

	  @Test
	  public void myTestMethod2() {
	    System.out.println("myTestMethod2");
	  }

}
