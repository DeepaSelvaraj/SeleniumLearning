package testNG;


import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class MultipleClasses {
	
	WebDriver driver;
	long startTime;
	static Logger log = Logger.getLogger(MultipleClasses.class);
	
	@BeforeSuite
	public void launchBrowser(){
		DOMConfigurator.configure("log4j.xml");
		 startTime   = System.currentTimeMillis();
		System.setProperty("webdriver.chrome.driver","C:\\Users\\dselva001c\\chromedriver_win32\\chromedriver.exe");
		driver =  new ChromeDriver();
		  log.info("Chrome opened");
		  driver.manage().window().maximize();
	}
	
	
	
	@Test
	public void OpneGoogle() {
		
		log.info("Opening google.com");
		
		driver.get("https://www.google.com");
	
		 
	    }

	@Test
	public void OpneBing() {
		
		log.info("Opening Bing.com");
		driver.get("https://www.bing.com");
	
	}
	
	@Test
	public void OpneYahoo() {
		log.info("Opening yahoo.com");
		driver.get("https://www.yahoo.com");
		
	}
	
	
	
	@AfterSuite
	public void afterSuite() {
		
		log.info("Work done");
		driver.quit();
		 long endTime   = System.currentTimeMillis();
	        long totalTime = endTime - startTime;
	        log.info(totalTime/1000.0+" seconds");
	}
}
