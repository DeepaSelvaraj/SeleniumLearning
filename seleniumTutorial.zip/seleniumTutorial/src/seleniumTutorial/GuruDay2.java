  
package seleniumTutorial;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GuruDay2 {

	private static boolean Boolean;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\dselva001c\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.demo.guru99.com/V4/");
		WebElement username = driver.findElement(By.name("uid"));
		username.sendKeys("mngr10928");
		WebElement password = driver.findElement(By.name("password"));
		password.sendKeys("rUjEbUs");
		WebElement button = driver.findElement(By.name("btnLogin"));
		button.click();
		
		
		//alert handling
		
	Alert alert = driver.switchTo().alert();
	String message = alert.getText();
 if(message.equals("User or Password is not valid")) 
	 
 {
	 System.out.println("User or Password is not valid");
 }
 alert.accept();
 WebElement username1 = driver.findElement(By.name("uid"));
	username1.sendKeys("mngr109282");
	WebElement password1 = driver.findElement(By.name("password"));
	password1.sendKeys("rUjEbUs1");
	WebElement button1 = driver.findElement(By.name("btnLogin"));
	button1.click();
	Alert alert2 = driver.switchTo().alert();
	String message2 = alert.getText();
	if(message2.equals("User or Password is not valid")) {
	System.out.println("User or Password is not valid");
    
	}
	alert2.accept();
	
	
	WebElement username11 = driver.findElement(By.name("uid"));
	username11.sendKeys("mngr109282");
	WebElement password11 = driver.findElement(By.name("password"));
	password11.sendKeys("rUjEbUs");
	WebElement button11 = driver.findElement(By.name("btnLogin"));
	button11.click();
	
	
	WebElement loginpage = driver.findElement(By.linkText("Log out"));
	Boolean result = loginpage.isDisplayed();
	
	if(result.equals(true)) {
		System.out.println("Login success");
		
	}
	else
	{
		System.out.println("Login not successful");
	}
	}
}


