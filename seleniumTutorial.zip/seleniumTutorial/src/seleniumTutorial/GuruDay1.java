package seleniumTutorial;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GuruDay1 {

	public static void main(String[] args) {
		// TODO Auto-generate
		System.setProperty("webdriver.chrome.driver","C:\\Users\\dselva001c\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get(" http://www.demo.guru99.com/V4/");
		//enter username
		WebElement username = driver.findElement(By.name("uid"));
		username.sendKeys("mngr109282");
		WebElement password = driver.findElement(By.name("password"));
		password.sendKeys("rUjEbUs");
		WebElement button = driver.findElement(By.name("btnLogin"));
		button.click();
		
		
		
		//validating login page
		
		WebElement loginpage = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[3]/td"));
		String login = loginpage.getText();
		if(login.equals("Manger Id : mngr109282"))
		{
			System.out.println("Login successful");
		}
		
		else
		{
			System.out.println();
		}
		
		
		
		

	}

}
