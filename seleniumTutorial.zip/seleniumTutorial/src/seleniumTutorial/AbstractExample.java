package seleniumTutorial;

public abstract class AbstractExample {
	abstract void run();
}

class Honda4 extends AbstractExample{  
void run()
{System.out.println("running safely..");}  

public static void main(String args[]){  
	AbstractExample obj = new Honda4();  
 obj.run();  
}  
}  


