package seleniumTutorial;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropdownExample {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\dselva001c\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.echoecho.com/htmlforms11.htm");
				/*driver.findElement(By.name("dropdownmenu"));
		Select select = new Select(By.("Milk"));*/
		WebElement name = driver.findElement(By.name("dropdownmenu"));
		Select select = new Select(name);
	List<WebElement> list = select.getOptions();
	int size =list.size();
	for(int i=0; i<size; i++)
	{
	System.out.println(list.get(i).getText());
	}
		

		

	}

}
