package seleniumTutorial;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alerthandling {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\dselva001c\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.javascriptkit.com/javatutors/alert2.shtml");
		//driver.findElement(By.name("B2")).click();
		//driver.findElement(By.name("B3")).click();
		driver.findElement(By.name("B4")).click();
		Alert alert = driver.switchTo().alert();
		Thread.sleep(2000);
		//alert.accept();
		//alert.dismiss();
		alert.sendKeys("java");
		//Thread.sleep(2000);
		alert.accept();
		String name = alert.getText();
	  if(name.equals("Java"))
	  {
		
		System.out.println("Validation is successful");	
		
	}
	  else
	  {
		  System.out.println("Validation is not successful");
	  }
	  alert.accept();

}
}
